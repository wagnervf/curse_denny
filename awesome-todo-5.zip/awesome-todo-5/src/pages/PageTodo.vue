<template>
  <q-page padding>
		<p>Todo Page</p>
  </q-page>
</template>

<script>
	export default {

	}
</script>

<style>
	
</style>
