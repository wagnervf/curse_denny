<template>
  <q-page padding>
		<p>Settings page</p>
  </q-page>
</template>

<script>
	export default {

	}
</script>

<style>
	
</style>
